[![StyleCI](https://github.styleci.io/repos/106201322/shield?branch=master)](https://github.styleci.io/repos/106201322)

# simple-money-format
JQuery Simple Money Format for my personal usage

## Installation

Clone or download repo and add simple.money.format.js to your project.

## Usage


    $('.money').simpleMoneyFormat();
    

## License

MIT
